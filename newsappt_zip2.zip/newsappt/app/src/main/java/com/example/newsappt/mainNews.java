package com.example.newsappt;

import java.util.ArrayList;

public class mainNews {

    private String sattus;
    private String totalResults;
    private ArrayList<ModalClass> articles;

    public mainNews(String sattus, String totalResults, ArrayList<ModalClass> articles) {
        this.sattus = sattus;
        this.totalResults = totalResults;
        this.articles = articles;
    }

    public String getSattus() {
        return sattus;
    }

    public void setSattus(String sattus) {
        this.sattus = sattus;
    }

    public String getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(String totalResults) {
        this.totalResults = totalResults;
    }

    public ArrayList<ModalClass> getArticles() {
        return articles;
    }

    public void setArticles(ArrayList<ModalClass> articles) {
        this.articles = articles;
    }
}
